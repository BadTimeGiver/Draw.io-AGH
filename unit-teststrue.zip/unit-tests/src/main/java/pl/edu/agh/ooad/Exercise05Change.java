package pl.edu.agh.ooad;

public final class Exercise05Change {
    
    public final static int[] NOMINAL_VALUES = new int[]{50, 20, 10, 5, 2, 1};
    
    public static int[] countChanges(int amount) {
        int[] result = new int[NOMINAL_VALUES.length];
        // TODO: implement
        
        return result;
    }
    
}
