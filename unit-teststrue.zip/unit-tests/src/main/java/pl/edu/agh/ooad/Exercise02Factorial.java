package pl.edu.agh.ooad;

public final class Exercise02Factorial {
    
    public static int factorial(int x) {
        if (x<0){
            throw new IllegalArgumentException("Negative value not supported");
        }
        if (x==0){
            return 1;
        }
        return x*factorial(x-1);
    }
    
}

