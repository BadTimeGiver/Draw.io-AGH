package pl.edu.agh.ooad;

public final class Exercise03GCD {
    
    public static int greatestCommonDivisor(int n, int m) {
        if (n<0 || m<0){
            return greatestCommonDivisor(Exercise01Abs.abs(n),Exercise01Abs.abs(m));
        }
        if(n==0){
            return m;
        }
        if (m==0){
            return n;
        }
        if (m>n){
            return greatestCommonDivisor(m,n);
        }
        int remainder=n%m;
        return greatestCommonDivisor(m,remainder);
    }
}
