package pl.edu.agh.ooad;

public final class Exercise04Fibonacci {
    
    public static int fibonacci(int n) {
        // TODO: implement
        return 0;
    }
}
