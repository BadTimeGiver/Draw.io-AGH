package pl.edu.agh.ooad;

public final class Exercise01Abs {
    
    public static int abs(int x) {
        if (x<0) {
            x = x * -1;
        }
        return x;
    }
}
