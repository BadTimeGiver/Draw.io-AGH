package pl.edu.agh.ooad;


import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class Exercise03GCDTest {
    @Test
    @DisplayName("Test GCD of positive values")
    public void testGCDpositive(){
        //given
        int gcdOfTenAndFive=5;

        //when
        int result= Exercise03GCD.greatestCommonDivisor(5,10);

        //then
        assertEquals(result,gcdOfTenAndFive);

    }
    @Test
    @DisplayName("Test GCD of 0 with 0")
    public void testGCDnull(){
        //given
        int gcdOf0=0;

        //when
        int result= Exercise03GCD.greatestCommonDivisor(0,0);

        //then
        assertEquals(result,gcdOf0);

    }
}
