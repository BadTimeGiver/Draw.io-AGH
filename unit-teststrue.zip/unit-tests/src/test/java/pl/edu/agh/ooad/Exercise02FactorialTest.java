package pl.edu.agh.ooad;


import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class Exercise02FactorialTest {
    @Test
    @DisplayName("Test Factorial of zero")
    public void testFactorialOfZero(){
        //given
        int factorialOfZero=1;

        //when
        int result = Exercise02Factorial.factorial(0);

        //then
        assertEquals(factorialOfZero,result);
    }
    @Test
    @DisplayName("Test Factorial of positive values")
    public void testFactorialOfPositive(){
        //given
        int factorialOfFive=120;

        //when
        int result = Exercise02Factorial.factorial(5);

        //then
        assertEquals(factorialOfFive,result);
    }



}
