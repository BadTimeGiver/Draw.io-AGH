package pl.edu.agh.ooad;


public class Exercise04FibonacciTest {

}
